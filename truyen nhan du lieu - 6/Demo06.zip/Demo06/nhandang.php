<html>
<head>
	<title>PHP 02</title>
</head>

<body>
	
	<?php
		echo "Ma nhan dien la: " . $_GET["Ma"];
	?>
</body>
</html>