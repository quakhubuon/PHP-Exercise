<html>
<head>
	<title>PHP 02</title>
</head>

<body>

	<h1>Tim sach</h1>
	<form action="xltimSach.php" method ="get">
		Keyword: <input type="text" name="txtTukhoa"/>
		<input type ="submit" value="Search">
	</form>
</body>
</html>