<html>
<head>
	<title>PHP 02</title>
</head>

<body>
	<form action="xuly.php" Method="POST" > 
		Keyword: <input type="text" name="txtTukhoa"/>
		<input type="submit" value="Search"/>
	</form>

	<?php
		
		if (isset($_REQUEST["txtTukhoa"]))
		{
			$sTukhoa = $_REQUEST["txtTukhoa"];
			print " Keyword is: $sTukhoa";
			echo "<br> Result :";
		}
	?>
</body>
</html>