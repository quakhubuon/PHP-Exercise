<?php 
	// db parameters
	$dbhost = 'localhost';
	$dbuser = 'root';
	$dbpass = '';
	$dbname = 'LopCLC';
	
	// connect
	$con = new mysqli($dbhost, $dbuser, $dbpass,$dbname) or die('Không thể kết nối CSDL');
	$con -> set_charset("utf8");  // for UTF-8
	
?>
