<?php
session_start();

$loai = $_REQUEST['loai'];
if(isset($loai))
{
	switch($loai)
	{
		case 0: // login
			if(login())
				header('Location:dangnhap.php?duoc=1');
			else
				header('Location:dangnhap.php?loi=1');
			break;
			
		case 1: // logout
			$_SESSION['username'] = NULL;
			header('Location:dangnhap.php');
			break;
			
		default: // do nothing
			header('Location:dangnhap.php');			
			break;
	}
}

// trả về true || false
function login()
{
	$username = $_REQUEST['txtUser'];
	$password = $_REQUEST['txtPass'];
	
	// giả sử dữ liệu đúng
	
	$con = new mysqli("localhost", "root", "","LopCLC");
	if (!$con)
	  {
	  die('Could not connect: ' . $con->connect_error);
	  }
	//print('connected');
	
	$con -> set_charset("utf8");  // for UTF-8
	
	//$sQuery = "select * from user where username = '" . $username . "'";
	
	//$sQuery = sprintf("select * from user where username = '%s'", $username);
	
	$sQuery = sprintf("select * from users where username = '%s'", $con->real_escape_string($username));
	
	$result  = $con->query($sQuery);
	
	if($result->num_rows == 1)
	{
		$row = $result->fetch_array();

		//$row[0] ~ $row['username']
		//$_SESSION['username'] = $username;
		if ($row['password'] == $password)
		{
			// login đúng
			$_SESSION['username'] = $username;
			//echo('Logined');
			$con->close();
			return true;
		}
	}
	$con->close();	
	// lỗi
	header('Location:dangnhap.php?loi=1');
	return false;
}

?>