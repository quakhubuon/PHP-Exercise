
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>String PHP Demo</title>
    </head>
    
    <body>
    	<?php
			print("I said: 'Hello' # ");
			print('I said: "Hello" # ' . '<br>');
			print("I said: \"Hello' # ");
			print('I said: "Hello\' # ');
		?>
    </body>
</html>