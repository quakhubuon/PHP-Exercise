// <!-- <mdb:mork:z v="1.4"/> -->
< <(a=c)> // (f=iso-8859-1)
  (B8=keywords)(B9=notAPhishMessage)(BA=current-view)(BB=account)
  (BC=retainBy)(BD=daysToKeepHdrs)(BE=numHdrsToKeep)(BF=daysToKeepBodies)
  (C0=keepUnreadOnly)(C1=useServerDefaults)(C2=cleanupBodies)
  (C3=origURIs)(C4=queuedDisposition)(C5=MRUTime)(C6=customSortCol)
  (C7=current-view-tag)(80=ns:msg:db:row:scope:msgs:all)(81=subject)
  (82=sender)(83=message-id)(84=references)(85=recipients)(86=date)
  (87=size)(88=flags)(89=priority)(8A=label)(8B=statusOfset)(8C=numLines)
  (8D=ccList)(8E=msgThreadId)(8F=threadId)(90=threadFlags)
  (91=threadNewestMsgDate)(92=children)(93=unrea