
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>Simple function call</title>
    </head>
    
    <body bgcolor="#ffffff" >	
    	<?php
        	include "functions.inc";
			//require "functions.inc";
			bold("this is bold");
			$myString = "this is bold";
			bold($myString);
		?>
    </body>
   

</html>