
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>Hello Everyone</title>
    </head>
    
    <body>
    	<?php
			print("PHP hello everyone.<br>");
		?>
		
		<?
			print("<i>PHP</i> Hello everyone.<br>");
		?>
		
		<script language="php">
			print("<b>PHP</b> Heloo everyone.");
		</script>
    </body>
</html>