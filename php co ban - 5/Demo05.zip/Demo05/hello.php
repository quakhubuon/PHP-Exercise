
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>Hello vorld</title>
    </head>
    
    <body>
    	<script type="text/javascript">
			document.write("<br>");
			document.write("JavaScript: Hello world !");
		</script>
        
        <?php
			echo("<br>");
			echo("PHP: Hello World !");
		?>
    </body>
</html>
