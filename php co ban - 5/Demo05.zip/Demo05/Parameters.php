
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Parameters</title>
</head>

<body>
	<?php
		$num =2.7;
		echo('Type of ' . $num . ' is : ' . gettype($num) . '<br/>');
		$num = 5;
		echo('Type of ' . $num . ' is : ' . gettype($num) . '<br/>');
		$str="Anyone";
		echo('Type of ' . $str . ' is : ' . gettype($str) . '<br/>');
		$bool = true;
		echo('Type of ' . $bool . ' is : ' . gettype($bool) . '<br/>');
	?>
    
</body>
</html>
