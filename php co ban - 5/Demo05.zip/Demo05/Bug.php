
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>Bug bug bug</title>
    </head>
    
    <body>
    	<?php
			echo('Hello world' . <br>');
			print('Hello everyone !');
		?>
		<br>
		Hello world
    </body>
</html>